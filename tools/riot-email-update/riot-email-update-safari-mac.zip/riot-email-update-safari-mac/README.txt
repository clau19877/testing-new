Your Desktop folder may be named:
  riot-email-update-safari-mac 3

KEEP your data/tasks.csv. Replace all other files from this zip into that folder.

Then in Terminal (note the quotes around the folder name):

  cd ~/Desktop/"riot-email-update-safari-mac 3"
  chmod +x run_safari_mac.sh run_safari_batch.sh fetch_riot_imap_code.py RUN_ME.command
  ./run_safari_mac.sh

Or double-click RUN_ME.command inside that folder.

If a dialog says BUILD 2026-08-09b, you have the correct script.
If it still says "Do not open this script directly", you are running an OLD copy.
