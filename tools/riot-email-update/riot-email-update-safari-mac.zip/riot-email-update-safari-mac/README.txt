Riot email update — Mac Safari batch

1. Unzip
2. Safari → Develop → Allow JavaScript from Apple Events
3. Fill data/tasks.csv (headers already present; see tasks.csv.example)
4. chmod +x *.sh fetch_riot_imap_code.py
5. ./run_safari_batch.sh data/tasks.csv

Outputs: success.txt / failed.txt
See MAC_SAFARI.md
