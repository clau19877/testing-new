Put account rows in data/tasks.csv, then:

  chmod +x *.sh fetch_riot_imap_code.py
  ./run_safari_mac.sh data/tasks.csv

Do NOT double-click the .applescript — that prompts for username.
