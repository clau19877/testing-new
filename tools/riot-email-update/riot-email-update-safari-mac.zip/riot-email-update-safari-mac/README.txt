Put this whole folder on your Mac, e.g.:

  Desktop/riotemail/

Put accounts in:

  Desktop/riotemail/data/tasks.csv

Then either:
  - Double-click RUN_ME.command
  - Or Terminal:
      cd ~/Desktop/riotemail
      chmod +x *.sh *.command fetch_riot_imap_code.py
      ./run_safari_mac.sh

Do NOT open safari_riot_email.applescript directly.
