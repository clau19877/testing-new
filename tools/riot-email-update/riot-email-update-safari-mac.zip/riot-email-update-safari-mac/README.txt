Riot email update — Mac Safari batch

1. Unzip
2. Safari → Develop → Allow JavaScript from Apple Events
3. Fill data/tasks.csv
4. chmod +x *.sh fetch_riot_imap_code.py
5. ./run_safari_batch.sh data/tasks.csv
