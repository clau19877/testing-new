Replace safari_riot_email.applescript, keep data/tasks.csv, then ./run_safari_mac.sh
