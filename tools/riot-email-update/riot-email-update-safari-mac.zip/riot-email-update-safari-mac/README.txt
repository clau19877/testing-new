BUILD 2026-08-09e

This zip does NOT include data/tasks.csv — keep yours.
Copy scripts into your Desktop folder, then:

  cd ~/Desktop/"riot-email-update-safari-mac 3"
  chmod +x *.sh *.command fetch_riot_imap_code.py
  ./run_safari_mac.sh
