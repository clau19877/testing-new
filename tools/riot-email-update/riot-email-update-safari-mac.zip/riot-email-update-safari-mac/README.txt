cd ~/Desktop/riotemail
chmod +x run_safari_mac.sh run_safari_batch.sh fetch_riot_imap_code.py RUN_ME.command
./run_safari_mac.sh

Keep your existing data/tasks.csv — only replace the .applescript / .sh files if updating.
