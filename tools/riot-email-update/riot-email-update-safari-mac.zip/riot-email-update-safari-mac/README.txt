IMPORTANT: fill data/tasks.csv with account rows, then run ONLY:

  chmod +x *.sh fetch_riot_imap_code.py
  ./run_safari_mac.sh

or:

  ./run_safari_batch.sh data/tasks.csv

Do NOT double-click safari_riot_email.applescript (that cannot see your CSV).
