BUILD 2026-08-09d

IMPORTANT: This zip does NOT include data/tasks.csv.
Keep your existing data/tasks.csv. Only replace the script files.

Update into your Desktop folder (example name):
  ~/Desktop/riot-email-update-safari-mac 3

Then:
  cd ~/Desktop/"riot-email-update-safari-mac 3"
  chmod +x *.sh *.command fetch_riot_imap_code.py
  ./run_safari_mac.sh

A good build shows BUILD 2026-08-09d.
