Put accounts in data/tasks.csv, then either:

  ./run_safari_mac.sh
  or double-click RUN_ME.command

If you open safari_riot_email.applescript directly, it will offer to
run the batch from data/tasks.csv beside it.
