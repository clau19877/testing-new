Riot email update — macOS Safari batch
======================================

1) Safari → Settings → Advanced → Show Develop menu
2) Develop → Allow JavaScript from Apple Events  (ON)

3) Run:
   cd riot-email-update-safari-mac
   chmod +x run_safari_batch.sh run_safari_mac.sh fetch_riot_imap_code.py
   ./run_safari_batch.sh data/tasks.csv

4) Results:
   success.txt  — accounts that worked
   failed.txt   — accounts that failed (+ reason)

Your tasks.csv is already included under data/.
